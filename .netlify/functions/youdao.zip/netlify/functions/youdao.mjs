
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/youdao.js
var youdao_default = async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/youdao/, "");
  const target = `https://dict.youdao.com${path}${url.search}`;
  try {
    const r = await fetch(target);
    return new Response(await r.text(), {
      status: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  } catch {
    return new Response(JSON.stringify({ error: "\u4EE3\u7406\u5931\u8D25" }), { status: 502 });
  }
};
export {
  youdao_default as default
};
